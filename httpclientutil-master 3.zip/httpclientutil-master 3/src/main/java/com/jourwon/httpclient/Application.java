package com.jourwon.httpclient;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.jourwon.httpclient.pojo.HttpClientResult;
import com.jourwon.httpclient.pojo.OrderInterface;
import com.jourwon.httpclient.util.HttpClientUtils;
import com.jourwon.httpclient.util.SimpleDateUtil;

import java.math.BigDecimal;
import java.util.*;

/**
 * Description: 每日巡检入口
 * 早高峰、晚高峰、全天三个时间段的平均TPS、最大响应时间等信息统计
 *
 * @author 蒋家聪
 */
public class Application {

    /**
     * 默认配置早晚高峰时间段 统计最大响应时间
     */
    private static final String MORNING_START = "07:00";
    //全天时间以9点为标准，即昨天9点到今天9点为全天时间
    private static final String MORNING_END = "09:00";
    private static final String NIGHT_START = "18:00";
    private static final String NIGHT_END = "20:00";


    public static void main(String[] args) throws Exception {

        //输入晚早高峰的时间段，精准统计tps
        String yesterdayNightStartTps = "2020-06-11 18:00";
        String yesterdayNightEndTps = "2020-06-11 18:40";
        String morningStartTps = "2020-06-12 08:00";
        String morningEndTps = "2020-06-12 08:40";

        topTpsAndTime(yesterdayNightStartTps, yesterdayNightEndTps, morningStartTps, morningEndTps);
    }

    public static void topTpsAndTime(String yesterdayNightStartTps, String yesterdayNightEndTps, String morningStartTps, String morningEndTps) throws Exception {

        //晚高峰统计最大响应时间的开始时间
        String nightStartTime = yesterdayNightStartTps.substring(0, 11) + NIGHT_START;
        //晚高峰统计最大响应时间的结束时间
        String nightEndTime = yesterdayNightStartTps.substring(0, 11) + NIGHT_END;
        //早高峰统计最大响应时间的开始时间
        String morningStartTime = morningStartTps.substring(0, 11) + MORNING_START;
        //早高峰统计最大响应时间的结束时间
        String morningEndTime = morningStartTps.substring(0, 11) + MORNING_END;
        //全天统计开始时间
        String allDayStart = nightStartTime.substring(0, 11) + MORNING_END;
        //全天统计结束时间
        String allDayEnd = morningStartTime.substring(0, 11) + MORNING_END;

        top3Tps(yesterdayNightStartTps, yesterdayNightEndTps, morningStartTps, morningEndTps);
        top3Time(nightStartTime, nightEndTime, morningStartTime, morningEndTime, allDayStart, allDayEnd);
    }

    /**
     * 控制台打印早高峰、晚高峰、全天三个时间段的最大响应时间等信息
     *
     * @param yesterdayNightStart 昨天晚高峰开始时间
     * @param yesterdayNightEnd   昨天晚高峰结束时间
     * @param todayMorningStart   今天早高峰开始时间
     * @param todayMorningEnd     今天早高峰结束时间
     * @throws Exception
     */
    public static void top3Tps(String yesterdayNightStart, String yesterdayNightEnd, String todayMorningStart, String todayMorningEnd) throws Exception {

        //昨天晚高峰
        List<OrderInterface> NightTOrderInterfaces = getAll(yesterdayNightStart, yesterdayNightEnd);
        List<OrderInterface> NightTpstop3 = getByTPSTop3(NightTOrderInterfaces);

        //今早早高峰
        List<OrderInterface> MorningOrderInterfaces = getAll(todayMorningStart, todayMorningEnd);
        List<OrderInterface> MorningTpstop3 = getByTPSTop3(MorningOrderInterfaces);

        System.out.println("高峰接口TPS（top3)：\n" + "晚高峰");
        for (OrderInterface orderInterface : NightTpstop3) {
            System.out.println(orderInterface.getInterfaceName() + "（" + orderInterface.getTpsAvg() + "）");
        }
        System.out.println("\n\n" + "早高峰");
        for (OrderInterface orderInterface : MorningTpstop3) {
            System.out.println(orderInterface.getInterfaceName() + "（" + orderInterface.getTpsAvg() + "）");
        }
    }

    /**
     * 控制台打印早高峰、晚高峰、全天三个时间段的最大响应时间等信息
     *
     * @param nightStartTime 昨天晚高峰开始时间
     * @param nightEndTime   昨天晚高峰结束时间
     * @param morningStartTime   今天早高峰开始时间
     * @param morningEndTime     今天早高峰结束时间
     * @throws Exception
     */
    public static void top3Time(String nightStartTime, String nightEndTime, String morningStartTime, String morningEndTime, String allDayStart, String allDayEnd) throws Exception {

        //昨天晚高峰
        List<OrderInterface> NightTOrderInterfaces = getAll(nightStartTime, nightEndTime);
        List<OrderInterface> NightMaxTimeTop3 = getByMaxTimeTop3(NightTOrderInterfaces);

        //今早早高峰
        List<OrderInterface> MorningOrderInterfaces = getAll(morningStartTime, morningEndTime);
        List<OrderInterface> MorningMaxTimeTop3 = getByMaxTimeTop3(MorningOrderInterfaces);
        //全天24小时
        List<OrderInterface> allDayMaxTimeTop3 = getByMaxTimeTop3(getAll(allDayStart, allDayEnd));

        System.out.println("\n\n" + "5、时延最大的接口（top3)：\n" + "晚高峰");
        for (OrderInterface orderInterface : NightMaxTimeTop3) {
            System.out.println(orderInterface.getInterfaceName() + "（" + orderInterface.getResponseTimeMax() + "ms）");
        }

        System.out.println("\n\n" + "早高峰");
        for (OrderInterface orderInterface : MorningMaxTimeTop3) {
            System.out.println(orderInterface.getInterfaceName() + "（" + orderInterface.getResponseTimeMax() + "ms）");
        }

        System.out.println("\n\n" + "全天");
        for (OrderInterface orderInterface : allDayMaxTimeTop3) {
            System.out.println(orderInterface.getInterfaceName() + "（" + orderInterface.getResponseTimeMax() + "ms）");
        }
    }

    /**
     * 根据开始时间、结束时间筛选出所有指定接口
     *
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @return 所有接口
     * @throws Exception
     */
    public static List getAll(String startTime, String endTime) throws Exception {

        List<OrderInterface> lists = new ArrayList<>();
        //输入时间格式参考："yyyy-MM-dd HH:mm:ss"  返回值参考：1591545600000
        long stratTimeByLong = SimpleDateUtil.dateToLong(startTime);
        long endTimeByLong = SimpleDateUtil.dateToLong(endTime);

        //请求访问监控大盘
        String url_cp_order = String.format("http://ccmp.caocaokeji.cn/monitor-proxy/monitor/analysis/stat/performance/query?startTime=%d&endTime=%d&appName=cp-order&interfaceName=", stratTimeByLong, endTimeByLong);
        HttpClientResult result = HttpClientUtils.doGet(url_cp_order);
        JSONObject jsonObject = JSONObject.parseObject(result.getContent());
        JSONArray jsonArray2 = jsonObject.getJSONArray("data");
        List<OrderInterface> orderInterfaces = jsonArray2.toJavaList(OrderInterface.class);
        // JSONObject jsonObject = JSONObject.fromObject(result.getContent());
        // JSONArray jsonArray2 = JSONArray.fromObject(jsonObject.get("data"));
        //
        // List<OrderInterface> orderInterfaces = (List<OrderInterface>) JSONArray.toCollection(jsonArray2, OrderInterface.class);

        return orderInterfaces;
    }

    /**
     * 根据接口列表筛选平均TPS中top3的接口
     *
     * @param lists
     * @return
     */
    public static List getByTPSTop3(List<OrderInterface> lists) {

        List<OrderInterface> tpsTop3 = new ArrayList<>();

        Collections.sort(lists, new Comparator<OrderInterface>() {

            @Override
            public int compare(OrderInterface o1, OrderInterface o2) {

                //按照接口的的tps进行降序排列
                BigDecimal b1 = new BigDecimal(o1.getTpsAvg());
                BigDecimal b2 = new BigDecimal(o2.getTpsAvg());
                // -1：小于；   0 ：等于；   1 ：大于；
                if (b1.compareTo(b2) == -1) {
                    return 1;
                }

                if (b1.compareTo(b2) == 0) {
                    return 0;
                }
                return -1;
            }
        });

        for (OrderInterface orderInterface : lists.subList(0, 3)) {
            tpsTop3.add(orderInterface);
        }

        return tpsTop3;
    }

    /**
     * 根据接口列表筛选最大响应时间top3的接口
     *
     * @param lists
     * @return
     */
    public static List getByMaxTimeTop3(List<OrderInterface> lists) {

        List<OrderInterface> maxTimeTop3 = new ArrayList<>();

        Collections.sort(lists, new Comparator<OrderInterface>() {
            @Override
            public int compare(OrderInterface o1, OrderInterface o2) {

                //按照接口的的maxtime进行降序排列
                BigDecimal b1 = new BigDecimal(o1.getResponseTimeMax());
                BigDecimal b2 = new BigDecimal(o2.getResponseTimeMax());
                // -1：小于；   0 ：等于；   1 ：大于；
                if (b1.compareTo(b2) == -1) {
                    return 1;
                }

                if (b1.compareTo(b2) == 0) {
                    return 0;
                }

                return -1;
            }
        });

        for (OrderInterface orderInterface : lists.subList(0, 3)) {
            maxTimeTop3.add(orderInterface);
        }

        return maxTimeTop3;
    }

}
