package com.jourwon.httpclient.pojo;

import lombok.Data;
import org.springframework.util.StringUtils;

/**
 * 〈简单可转债信息〉
 *
 * @author jiacong.jiang
 * @create 2021/5/24
 * @since 1.0.0
 */
@Data
public class SimpleCell {

    /**
     * 可转债id
     */
    private String bond_id;

    /**
     * 可转债name
     */
    private String bond_nm;
    /**
     * 可转债对应行业
     */
    private String sw_cd;

    /**
     * 行业name
     */
    private String sw_nm_r;

    /**
     * 评级
     */
    private String rating_cd;

    /**
     * 转股价值
     */
    private double convert_value;

    /**
     * 溢价率
     */
    private double premium_rt;

    /**
     * 规模，单位亿
     */
    private double curr_iss_amt;
}
