package com.jourwon.httpclient.pojo;

import lombok.Data;

/**
 * 〈可转债信息〉
 *
 * @author jiacong.jiang
 * @create 2021/5/24
 * @since 1.0.0
 */
@Data
public class Convertible {

    /**
     * 正股id
     */
    private String id;

    /**
     * 可转债信息
     */
    private Cell cell;
}
