package com.jourwon.httpclient;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.jourwon.httpclient.pojo.*;
import com.jourwon.httpclient.util.ArithUtils;
import com.jourwon.httpclient.util.HttpClientUtils;
import com.jourwon.httpclient.util.SimpleDateUtil;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;
import com.google.common.collect.Lists;

/**
 * 〈可转债价格预估〉
 *  集思录可转债地址：https://www.jisilu.cn/data/cbnew/#pre
 *
 * @author jiacong.jiang
 * @create 2021/5/24
 * @since 1.0.0
 */
public class ApplicationByMoney {

    /**
     * 待发转债列表
     */
    private static final String GET_CELL_URL= "https://www.jisilu.cn/data/cbnew/pre_list/?___jsl=LST___t=1621832889635";

    /**
     * 全部可转债列表
     */
    private static final String GET_LIST_URL = "https://www.jisilu.cn/webapi/cb/list/";

    /**
     * 全部可转债对应的简单信息
     */
    private static List<SimpleCell> simpleCells;

    /**
     * 可申购转债的映射关系
     */
    private static Map<Cell, List<SimpleCell>> map = new HashMap<>();

    // 首先获取全部的转债信息
    static {

        HttpClientResult result = null;

        try {
            result = HttpClientUtils.doGet(GET_LIST_URL);
        } catch (Exception e) {
            e.printStackTrace();
        }

        JSONObject jsonObject = JSONObject.parseObject(result.getContent());
        JSONArray jsonArray2 = jsonObject.getJSONArray("data");

        simpleCells = jsonArray2.toJavaList(SimpleCell.class);
    }


    public static void main(String[] args) throws Exception {

        // 获取明日日期
        String time = SimpleDateUtil.getPurchaseDate();

        // 获取指定可申购转债信息
        List<Cell> result = getResult(time);

        // List<Cell> result = getResult("2021-05-25");

        if (CollectionUtils.isEmpty(result)) {
            System.out.println(time + "无申购转债");
            return;
        }

        // 构建可转债以及对应参照物的映射关系
        buildMap(result);

        //打印结果
        print();

    }

    public static void print() {
        for (Map.Entry<Cell, List<SimpleCell>> entry : map.entrySet()) {

            Cell key = entry.getKey();
            List<SimpleCell> value = entry.getValue();

            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("时间："
                    + key.getProgress_dt()
                    + "  "
                    + "可申购可转债："
                    + key.getBond_nm()
                    + "  "
                    + "等级："
                    + key.getRating_cd()
                    + "  "
                    + "转股价值"
                    + key.getPma_rt()
                    + "  "
                    + "发行数量（亿）："
                    + key.getAmount()
            );

            if (CollectionUtils.isEmpty(value)) {
                System.out.println("无对照物");
                break;
            }

            System.out.println("对照物集合：");
            for (SimpleCell simpleCell : value) {
                System.out.println(
                          "名称=" + simpleCell.getBond_nm()
                        + "   ,所属行业=" + simpleCell.getSw_nm_r()
                        + "   ,级别=" + simpleCell.getRating_cd()
                        + "   ,转股价值=" + simpleCell.getConvert_value()
                        + "   ,溢价率=" + simpleCell.getPremium_rt() + "%"
                        + "   ,发行规模（亿）=" + simpleCell.getCurr_iss_amt());
            }

            // 是否有同级别的可转债
            boolean hasRating = false;
            for (SimpleCell simpleCell : value) {
                if (simpleCell.getRating_cd().equals(key.getRating_cd())) {
                    hasRating = true;
                    break;
                }
            }

            SimpleCell max = null;
            double min = Double.MAX_VALUE;

            // 有同级别转债，取转股价值最近的
            if (hasRating) {
                for (SimpleCell simpleCell : value) {

                    if (!simpleCell.getRating_cd().equals(key.getRating_cd())) {
                        continue;
                    }

                    double var = simpleCell.getConvert_value() - Double.valueOf(key.getPma_rt());
                    // 绝对值
                    double abs = Math.abs(var);
                    if (abs < min) {
                        min = abs;
                    }
                    max = simpleCell;
                }
            } else {
                for (SimpleCell simpleCell : value) {
                    double var = simpleCell.getConvert_value() - Double.valueOf(key.getPma_rt());
                    // 绝对值
                    double abs = Math.abs(var);
                    if (abs < min) {
                        min = abs;
                    }
                    max = simpleCell;
                }
            }

            // 溢价率是否偏高
            boolean isHigher =  ArithUtils.sub(Double.valueOf(key.getPma_rt()), max.getConvert_value())  > 0;
            // 转股价值 * （1+溢价率）/1
            double result = ArithUtils.doubleBitUp(Double.valueOf(key.getPma_rt()) * (100 + max.getPremium_rt())/100, 2);
            // 发行总量
            double b1 = Double.valueOf(key.getAmount());
            // 线上配售比例
            double b2 = 0.5;
            // 线上配售量
            double scale = ArithUtils.mul(b1, b2);

            double win = ArithUtils.div(ArithUtils.mul(scale, 10000.0), 700 * 1000.0, 3);

            System.out.println("");
            System.out.println("选择：");
            System.out.println(
                    "名称=" + max.getBond_nm()
                            + "   ,所属行业=" + max.getSw_nm_r()
                            + "   ,级别=" + max.getRating_cd()
                            + "   ,转股价值=" + max.getConvert_value()
                            + "   ,溢价率=" + max.getPremium_rt() + "%"
                            + "   ,发行规模（亿）=" + max.getCurr_iss_amt());
            System.out.println("");


            System.out.print("一手预估盈利 ： 转股价值 * 溢价率 = "
                    + key.getPma_rt() + "*" + ArithUtils.add(100.0, max.getPremium_rt()) + "% = " + result + "元   ");
            System.out.println("预估盈利值偏" + (isHigher ?"高":"低"));
            System.out.println("");


            System.out.println("发行规模："+ key.getAmount() +"亿，假设股东配售率为50%，网上发行规模预计"+ scale + "亿");
            System.out.println("若按照网上700万户申购，单账户中签率=" + ArithUtils.mul(scale, 10000.0).intValue() + "/700/1000" +"="+ win +
                    "手，即单账户中签1手概率约为"+ ArithUtils.mul(win, 100.0) + "%");
            System.out.println("******************************************************************************************************************");
        }
    }


    /**
     * 查询指定转债对应行业的其余转债信息，并放入map，
     * key：指定转债 value：当前所在行业内其余转债集合
     *
     * @throws Exception
     */
    public static void buildMap(List<Cell> result) throws Exception {

        for(Cell cell: result) {
            String businessCode = getBusinessCode(cell.getBond_id());
            cell.setSubBusinessCode(businessCode.substring(0,2));
        }

        for(SimpleCell simpleCell : simpleCells) {
            if (null != simpleCell.getSw_cd()) {
                for (Cell cell : result){
                    if (simpleCell.getSw_cd().substring(0, 2).equals(cell.getSubBusinessCode())){
                        if (cell.getBond_id().equals(simpleCell.getBond_id())) {
                            break;
                        }
                        if (map.containsKey(cell)){
                            map.get(cell).add(simpleCell);
                        } else {
                            map.put(cell, Lists.newArrayList(simpleCell));
                        }
                    }
                }
            }
        }
    }

    /**
     * 获取指定可转债的行业id
     *
     * @param id 可转债id
     * @return 所在行业id
     * @throws Exception
     */
    public static String getBusinessCode(String id) throws Exception {

        if (StringUtils.isEmpty(id)) {
            return null;
        }

        for(SimpleCell simpleCell : simpleCells) {
            if (id.equals(simpleCell.getBond_id())) {
                return simpleCell.getSw_cd();
            }
        }
                
        return null;
    }



    /**
     * 获取指定可申购可转债信息
     * @param time 明日日期
     * @return 可申购转债信息
     *
     * @throws Exception
     */
    public static List<Cell> getResult(String time) throws Exception {

        if (StringUtils.isEmpty(time)) {
            Collections.emptyList();
        }

        //请求访问 集思录
        HttpClientResult result = HttpClientUtils.doPost(GET_CELL_URL);

        JSONObject jsonObject = JSONObject.parseObject(result.getContent());
        JSONArray rows = jsonObject.getJSONArray("rows");

        List<Convertible> convertibles = rows.toJavaList(Convertible.class);

        // 无可转债信息
        if (CollectionUtils.isEmpty(convertibles)) {
            return Collections.emptyList();
        }

        List<Cell> collect = convertibles.stream()
                .filter(Objects::nonNull)
                .filter(convertible -> Objects.nonNull(convertible.getCell()))
                // 指定日期有进展公告的转债
                .filter(convertible -> time.equals(convertible.getCell().getProgress_dt()))
                // 无中签率 && 转债id不为空，即指定日期可申购转债
                .filter(convertible -> Objects.isNull(convertible.getCell().getLucky_draw_rt()) && !StringUtils.isEmpty(convertible.getCell().getBond_id()))
                .map(Convertible::getCell)
                .collect(Collectors.toList());

        return collect;
    }
}
