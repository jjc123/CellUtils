package com.jourwon.httpclient.pojo;

/**
 * 〈cp-order接口〉
 *
 * @author 蒋家聪
 * @create 2020/6/9
 * @since 1.0.0
 */
public class OrderInterface {
     public String getInterfaceName() {
          return interfaceName;
     }

     public void setInterfaceName(String interfaceName) {
          this.interfaceName = interfaceName;
     }

     private String interfaceName;
     private String tpsAvg;
     private String responseTimeMax;

     public String getTpsAvg() {
          return tpsAvg;
     }

     public void setTpsAvg(String tpsAvg) {
          this.tpsAvg = tpsAvg;
     }

     public String getResponseTimeMax() {
          return responseTimeMax;
     }

     public void setResponseTimeMax(String responseTimeMax) {
          this.responseTimeMax = responseTimeMax;
     }
}
