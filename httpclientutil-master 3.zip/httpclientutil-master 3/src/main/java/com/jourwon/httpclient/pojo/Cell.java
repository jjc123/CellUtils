package com.jourwon.httpclient.pojo;

import lombok.Data;
/**
 * 〈转债信息〉
 *
 * @author jiacong.jiang
 * @create 2021/5/24
 * @since 1.0.0
 */
@Data
public class Cell {

    /**
     * 正股id
     */
    private String stock_id;

    /**
     * 正股name
     */
    private String stock_nm;

    /**
     * 转债id
     */
    private String bond_id;

    /**
     * 转债名称
     */
    private String bond_nm;

    /**
     * 申购日期，格式：2021-05-24
     */
    private String progress_dt;

    /**
     * 转股价值 = （100/转股价 * 正股价） 需自己拼接%
     */
    private String pma_rt;

    /**
     * 发行规模
     */
    private String amount;

    /**
     * 评级
     */
    private String rating_cd;

    /***********************************************************************************************/
    /**
     * 股东配售率，保留3位小数，默认无
     */
    private String ration_rt;

    /**
     * 申购户数，保留2位小数，默认无
     */
    private String valid_apply;

    /**
     * 中签率，保留4位小数，根据这个判断是否是明天申购的转债，默认无
     */
    private String lucky_draw_rt;

    /**
     * 所在行业id截取前两位
     */
    private String subBusinessCode;
}
