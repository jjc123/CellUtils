package com.jourwon.httpclient.util;


import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * 〈时间戳转换〉
 *
 * @author 蒋家聪
 * @create 2020/6/9
 * @since 1.0.0
 */
public class SimpleDateUtil {

    public static String TIME_FORMAT = "yyyy-MM-dd HH:mm";

    /**
     * 将日期格式的字符串转换为长整型
     *
     * @param date
     * @return
     */
    public static long dateToLong(String date) {
        try {
            if (StringUtils.isNotBlank(date)) {
                SimpleDateFormat sf = new SimpleDateFormat(SimpleDateUtil.TIME_FORMAT);
                return sf.parse(date).getTime();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0L;
    }

    /**
     * 将长整型数字转换为日期格式的字符串
     *
     * @param time
     * @param format
     * @return
     */
    public static String longToDate(long time, String format) {
        if (time > 0L) {
            if (StringUtils.isBlank(format)) {
                format = SimpleDateUtil.TIME_FORMAT;
            }
            SimpleDateFormat sf = new SimpleDateFormat(format);
            Date date = new Date(time);
            return sf.format(date);
        }
        return "";
    }

    /**
     * 获取当前系统的日期
     *
     * @return
     */
    public static long curTimeMillis() {
        return System.currentTimeMillis();
    }

    /**
     * 获取明天日期
     * 格式：2021-04-16
     *
     * @return 明天日期
     */
    public static String getPurchaseDate() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date today = new Date();

        Calendar calendar = new GregorianCalendar();

        calendar.setTime(today);
        // 把日期往后增加一天.整数往后推,负数往前移动
        calendar.add(Calendar.DATE, 1);

        // 这个时间就是日期往后推一天的结果
        Date time = calendar.getTime();
        String tomorrow = format.format(time);

        return tomorrow;
    }
}